<?php
session_start();
include "file/booking_connection.php";
    $p_pnr=$_GET['p_pnr'];
	$status = 'Boarded';
	$sql = "UPDATE passenger_details SET p_status = '$status' WHERE p_pnr = '$p_pnr'";
    $sqls="SELECT p_fid from passenger_details where p_pnr='$p_pnr'";
    if (mysqli_query($conn, $sql)) {
        $result=mysqli_query($conn, $sqls);
    if ($result){
    $row = mysqli_fetch_array($result);
    // echo "<script>alert("Welcome to Geeks for Geeks")</script>";
	$msg="Passenger has been successfully boarded.";
	header("location:agentpd.php?p_fid=".$row['p_fid']."&msg=".$msg);
    }}else {
    $error= "Passenger hasn't boarded: " . mysqli_error($conn);
    header("location:agentpd.php?error=".$error );
    }
    mysqli_close($conn);
?>
<!-- <div class="row justify-content-center mb-3">
    <?php $counter=0; if(isset($_GET['msg'])) { ?>
        <div class="col-5 alert alert alert-success alert-dismissible fade show card" id="message">
            <button type="button" class="close" data-dismiss="alert" title="close">&times;</button><?php echo $_GET['msg'];?>
        </div>
    <?php }?>
    <?php if(isset($_GET['error'])) { ?>
        <div class="col-5 alert error alert-danger alert-dismissible fade show card" id="message">
            <button type="button" class="close" data-dismiss="alert" title="close">&times;</button><?php echo $_GET['error'];?>
        </div>
    <?php }?>
</div>
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script>
$( document ).ready(function(){
    $('#message').fadeIn('slow', function(){
        $('#message').delay(5000).fadeOut(); 
    });
});
</script>
<?php
echo '<script>alert("Welcome to Geeks for Geeks")</script>';
?> -->