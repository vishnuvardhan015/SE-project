<?php
require 'file/booking_connection.php';
session_start();
if(!isset($_SESSION['aaid']))
{
  header('location:loginasrs.php');
}
else {
?>

<!DOCTYPE html>
<html>
<?php $title="ASRS | Flight ID"; ?>
<?php require 'head.php'; ?>
<style>
    body{
    
    background-size: cover;
    min-height: 0;
    height: 900px;
  }
.login-form{
    width: calc(100% - 20px);
    max-height: 650px;
    max-width: 450px;
    background-color: white;
}
</style>
<body>
    <?php require 'headerasrs.php'; ?>
    <div class="container cont">
        
        <?php require 'message.php'; ?>
        
        <div class="row justify-content-center">
          
         <div class="col-lg-4 col-md-5 col-sm-6 col-xs-7 mb-5">
          <div class="card">
            <div class="card-header title">Enter Flight ID to open up the list</div>
        <div class="card-body">
        <form action="boardedpd.php">
          <input type="text" name="p_fid" placeholder="Flight ID" class="form-control mb-3" required>
          <input type="submit" name="add" value="Go" class="btn btn-primary btn-block"><br>
          <a href="agentpage.html" class="float-right" title="click here">Cancel</a>
        </form>
         </div>
       </div>
     </div>
    <?php } ?>
</div>
</div>
<?php require 'footer.php' ?></body></html>