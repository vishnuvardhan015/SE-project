<?php
session_start();
include "file/booking_connection.php";
    $p_pnr=$_GET['p_pnr'];
	$status = 'Booked';
	$sql = "UPDATE passenger_details SET p_status = '$status' WHERE p_pnr = '$p_pnr'";
    $sqls="SELECT p_fid from passenger_details where p_pnr='$p_pnr'";
    if (mysqli_query($conn, $sql)) {
        $result=mysqli_query($conn, $sqls);
    if ($result){
    $row = mysqli_fetch_array($result);
	$error="Passenger has been rejected from boarding.";
    echo "msg".$msg;
	header("location:boardedpd.php?p_fid=".$row['p_fid']."&error=".$error);
    }}else {
    $error= "Passenger hasn't boarded: " . mysqli_error($conn);
    header("location:boardedpd.php?error=".$error );
    }
    mysqli_close($conn);
?>