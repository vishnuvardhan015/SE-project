<?php
if(isset($_POST['aregister'])){
	require 'booking_connection.php';
	$aid=$_POST['aid'];
	$aname=$_POST['aname'];
	$aemail=$_POST['aemail'];
	$apassword=$_POST['apassword'];
	$aphone=$_POST['aphone'];
	$acity=$_POST['acity'];
	$check_email = mysqli_query($conn, "SELECT aemail,aid FROM agents where aemail = '$aemail' or aid = '$aid'");
	if(mysqli_num_rows($check_email) > 0){
    $error= 'Email or Personal ID Already exists. Please try another Email or another Personal ID.';
    header( "location:../register.php?error=".$error );
}else{
	$sql = "INSERT INTO agents (aid, aname, aemail, apassword, aphone, acity)
	VALUES ('$aid', '$aname','$aemail', '$apassword', '$aphone', '$acity')";
	if ($conn->query($sql) === TRUE) {
		$msg = "You have successfully registered. Please, login to continue.";
		header( "location:../loginasrs.php?msg=".$msg);
	} else {
		$error = "Error: " . $sql . "<br>" . $conn->error;
        header( "location:../register.php?error=".$error );
	}
	$conn->close();
}
}
?>