<?php
session_start();
require 'booking_connection.php';
$flightBookingId = $_GET['flightBookingId'];
$flightId = $_GET['flightId'];
$uid=$_SESSION['uid'];
$selected=$_GET['selected'];
$pnr = $_GET['pnr'];
$p_extra='Rs.2000';
$p_extras='Rs.1500';
$my_array = array("7A","7F","8A","8F","9A","9F","10A","10F","1A","1F","2A","2F","3A","3F","4A","4F","5A","5F","6A","6F");
list($a,$b,$c,$d,$e,$f,$g,$h,$i,$j,$k,$l,$m,$n,$o,$p,$q,$r,$s,$t) = $my_array;

if ($flightBookingId != "") {
    $selectedSeatIdString = $_GET['selectedSeatIdString'];

    $sql = "UPDATE flight_booking SET seats = '$selectedSeatIdString' WHERE flight_booking_id = '$flightBookingId'";
    if ($conn->query($sql) === TRUE) {
        $sqlNew = "UPDATE passenger_details SET p_status = 'Booked',p_seats = '$selected' WHERE uid = '$uid' and p_fid = '$flightId' and p_pnr='$pnr'";
        if ($conn->query($sqlNew) === TRUE) {
            if($selected==$a or $selected==$b or $selected==$c or $selected==$d or $selected==$e or $selected==$f or $selected==$g or $selected==$h){
                $sqlN = "UPDATE passenger_details SET p_extra='$p_extra' WHERE uid = '$uid' and p_fid = '$flightId' and p_pnr='$pnr'";
        if ($conn->query($sqlN) === TRUE) {}
           }
       if($selected==$i or $selected==$j or $selected==$k or $selected==$l or $selected==$m or $selected==$n or $selected==$o or $selected==$p or $selected==$q or $selected==$r or $selected==$s or $selected==$t){
                $sqlNs = "UPDATE passenger_details SET p_extra='$p_extras' WHERE uid = '$uid' and p_fid = '$flightId' and p_pnr='$pnr'";
        if ($conn->query($sqlNs) === TRUE) {}
           }
        } else {
            echo "$flightId.error added from flightBookingId.$conn->error";

        }

    } else {
        echo "error added from flightBookingId.$conn->error";
    }
} else {
    $selectedSeatIdString = $_GET['selectedSeatIdString'];

    $sql = "INSERT INTO flight_booking (seats,flight_id) VALUES ('$selectedSeatIdString', '$flightId')";
    if ($conn->query($sql) === TRUE) {
        $sqlNew = "UPDATE passenger_details SET p_status = 'Booked',p_seats = '$selected' WHERE uid = '$uid' and p_fid = '$flightId' and p_pnr='$pnr'";
        if ($conn->query($sqlNew) === TRUE) {
            if($selected==$a or $selected==$b or $selected==$c or $selected==$d or $selected==$e or $selected==$f or $selected==$g or $selected==$h){
                $sqlN = "UPDATE passenger_details SET p_extra='$p_extra' WHERE uid = '$uid' and p_fid = '$flightId' and p_pnr='$pnr'";
        if ($conn->query($sqlN) === TRUE) {}
           }
       if($selected==$i or $selected==$j or $selected==$k or $selected==$l or $selected==$m or $selected==$n or $selected==$o or $selected==$p or $selected==$q or $selected==$r or $selected==$s or $selected==$t){
                $sqlNs = "UPDATE passenger_details SET p_extra='$p_extras' WHERE uid = '$uid' and p_fid = '$flightId' and p_pnr='$pnr'";
        if ($conn->query($sqlNs) === TRUE) {}
           }
        } else {
            echo "error added from flightId.$conn->error";


        }

    } else {
        echo "error added from flightId.$conn->error";
    }
}
