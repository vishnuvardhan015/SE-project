<?php 
    session_start();

    ?>
<!DOCTYPE html>
<html><head>
<?php $title="ASRS | Promotion Codes"; ?>
<?php require 'head.php'; ?>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">Airline Seat Reservation System</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      
      <li class="nav-item active">
        <a class="nav-link" href="main.php">Home <span class="sr-only">(current)</span></a>
      </li>
      
      <li class="nav-item active">
        <a class="nav-link" href="about.php">About</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="contact.php">Contact</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="promotioncodes.php">Promo codes</a>
      </li>
       <li class="nav-item active">
        <a class="nav-link" href="loginasrs.php">Login/Register<span class="sr-only">(current)</span></a>
      </li>
    </ul>
  
  </div>
</nav>

    <div class="container cont">

        <div class="row justify-content-center">
            

            <div class="col-lg-9">
            <div class="row">
            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12 mb-5">
                <div class="card">
                    <div class="card-header text-center">Code:ASRS50</div>
                    <div class="card-body">
                        Upto 50% cashback on your first booking. TCA
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12 mb-5">
                <div class="card">
                    <div class="card-header text-center">Code:FLAT30P</div>
                    <div class="card-body">
                        30% unlimited cashback on Axis Bank Cards on a min spend of Rs. 5000. TCA 
                   </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12 mb-5">
                <div class="card">
                    <div class="card-header text-center">Code:500AIR</div>
                    <div class="card-body">
                         Flat 500 cashback on first Airtel Payments Bank transaction on Spicejet flights. TCA
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12 mb-5">
                <div class="card">
                    <div class="card-header text-center">Code:SLICE10</div>
                    <div class="card-body">
                        10% cashback on Slice Visa Card on min spend of Rs. 4500. TCA
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12 mb-5">
                <div class="card">
                    <div class="card-header text-center">Code:TRAVELSAFE</div>
                    <div class="card-body">
                         Get upto Rs. 1000 off on Rs. 5000 and above. TCA
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12 mb-5">
                <div class="card">
                    <div class="card-header text-center">Code:EXTRA20</div>
                    <div class="card-body"> 
                         Get upto Extra 20% off on min spend of Rs. 3500 and above.
                    </div>
                </div>
            </div>
            
            </div>
            </div>

        </div>

        <div class="row">
            <div class="col-lg-6 rounded mb-5">

            </div>
            <div class="col-lg-6 rounded mb-5">
                 </div>
        </div>

        <div class="row mb-5">
            <div class="col-lg-12">
            <div class="card">
                <div class="card-header">Travel tips</div>
                <div class="card-body">
                    <dt>PACK HEALTHY SNACKS</dt>
                    <dd>Almonds, apple slices, dried fruit, carrot sticks, and protein bars are great for holding you over when flying. If you pack snacks, you’re less likely to splurge on airport food that is often unhealthy and overpriced, plus you won’t arrive at your destination starving. Check out some of our favorite lightweight backpacking snacks that are easy to throw in your carry-on for when you are feeling hangry mid-flight.</dd>
                    <dt>BRING A SLEEPING KIT</dt>
                    <dd>Landing at your destination well rested will help set your trip off to a great start. Whether you’re stuck in a middle seat, leaning against the cold hard window, or winging it on the aisle, bringing a few small items with you will make your flight much more comfortable. Invest in a comfy travel pillow or better yet, use a backpacking pillow for flying. Also earplugs/earphones to help during takeoff and landing.</dd>
                    <dt>CHARGE UP YOUR DEVICES BEFORE YOUR FLIGHT</dt>
                    <dd>Make sure to have everything charged before heading to the airport. This may include your phone, laptop, camera, and any other electronics you travel with. You never know if you’ll be able to find an open outlet or if security might take longer than usual leaving no time to charge up.</dd>
                    <dt>TAKE AN IMMUNE SUPPLEMENT</dt>
                    <dd>When you fly you are sharing oxygen with 100+ people, who have recently shared air with another 100+ people. Get the idea? Plus you touch items that a high volume of other people touch such as security bins, seatbelts, tray tables, and door handles. Give your body a boost to fight off the germs with an immune supplement.</dd>
                    <dt>DOWNLOAD E-BOOKS, MUSIC AND MOVIES</dt>
                    <dd>WiFi on board can be expensive and slow, and not all routes offer in-flight entertainment. If you have a favorite tv show or a movie you’ve been wanting to watch, download it before boarding so you can watch it during your flight. Same goes for E-books and podcasts. If you have Netflix, it allows you to download movies and shows for offline viewing.</dd>
                    <dt>EXTRA TIPS(COVID):</dt>
                    <dt>Wear a mask and maintain 6ft Social distance</dt>
                    <dt>Get tested(COVID) before boarding</dt>
                    <dt>Wash your hands properly</dt>
                    <dt>Have regular check-ups</dt>
                    Visit here to get more health tips.
                    <a href="https://www.who.int/philippines/news/feature-stories/detail/20-health-tips-for-2020" target="_blank"> World Health Organisation</a>
                </div>
            </div>
            </div>
        </div>
    </div>

    <?php require 'footer.php'; ?>

</body>
</html>