<?php 
session_start();
require 'file/booking_connection.php';
global $p_fid;
if(!isset($_SESSION['aaid'])){
  header('location:loginasrs.php');
}

?>

<!DOCTYPE html>
<html>
<?php $title="ASRS | Bookings"; ?>
<?php require 'head.php'; ?>
<style>
    body{
    background-size: cover;
    min-height: 0;
    height: 1500px;
  }
</style>
<body>
    <?php require 'headerasrs.php'; ?>
    <div class="container cont">
        
        <?php require 'message.php'; ?>
        
        <div class="row col-lg-8 col-md-8 col-sm-12 mb-3">
            <form method="get" action="" style="margin-top:-50px; ">
            <label class="font-weight-bolder">Enter PNR:</label>
               <input name="search" class="form-control">
               <?php @$_GET['search']; ?>
               <input type="submit" name="submit" class="btn btn-info" value="search">
           </div>
           </form>
        </div>
<?php
    if(isset($_GET['search'])){
    $searchKey = $_GET['search'];
    $status='Boarded';
    $sql = "select * from passenger_details where p_pnr='$searchKey' and p_status='$status'";
    $result = mysqli_query($conn, $sql);}
else{
    $p_fid=$_GET['p_fid'];
    $status='Boarded';
    $sql = "select * from passenger_details where p_fid='$p_fid' and p_status='$status'";
    $result = mysqli_query($conn, $sql);
    }
  ?>
        <table class="table table-responsive table-striped rounded mb-15" style="position:relative; left:200px;">
            <tr><th colspan="22" class="title">Bookings</th></tr>
            <tr>
                <th>#</th>
                <th>PNR</th>
                <th>Name</th>
                <th>Age</th>
                <th>Gender</th>
                <th>Plane-Type</th>
                <th>From</th>
                <th>To</th>
                <th>Dep-date</th>
                <th>Arr-Date</th>
                <th>Dep-time</th>
                <th>Arr-time</th>
                <th>Status</th>
                <th>Class</th>
                <th>Pass-type</th>
                <th>Flight-Id</th>
                <th>Extra cost</th>
            </tr>
            <div>
                <?php
                if ($result){
                    $row =mysqli_num_rows($result);
                    if ($row){ //echo "<b> Total ".$row." </b>";
                }else echo '<b style="position:relative; left:200px;color:white;background-color:red;padding:7px;border-radius: 15px 50px;">No booking found or Boarding yet to be done</b>';
            }
            ?>
            </div>

        <?php while($row = mysqli_fetch_array($result)) { ?>

            <tr>
                <td><?php echo ++$counter;?></td>
                <td><?php echo ($row['p_pnr']);?></td>
                <td><?php echo ($row['p_name']); ?></td>
                <td><?php echo ($row['p_age']); ?></td>
                <td><?php echo ($row['p_sex']); ?></td>
                <td><?php echo ($row['p_fno']); ?></td>
                <td><?php echo $row['p_from'];?></td>
                <td><?php echo ($row['p_to']); ?></td>
                <td><?php echo ($row['p_dedate']); ?></td>
                <td><?php echo ($row['p_ardate']); ?></td>
                <td><?php echo ($row['p_detime']); ?></td>
                <td><?php echo $row['p_artime'];?></td>
                <td><?php echo ($row['p_status']); ?></td>
                <td><?php echo ($row['p_class']); ?></td>
                <td><?php echo ($row['p_passtype']); ?></td>
                <td><?php echo ($row['p_fid']); ?></td>
                <td><?php echo ($row['p_extra']); ?></td>
            <td><a href="boardingsdone.php?p_pnr=<?php echo $row['p_pnr'];?>" class="btn btn-danger">Cancel</a>
            </td>
            </tr>
        <?php } ?>
        </table>
    </div>
    <?php require 'footer.php' ?>
</body>
</html>