<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: white;
   color: black;
   text-align: center;
   padding: 5px 0px 5px 0px;
}
</style>
</head>
<body>

<div class="footer">
  <p>© Copyright 2021<span id="demo"></span> <span class="brand">ASRS</span> All Rights Reserved.
</footer></p>
</div>

</body>

<!-- Mirrored from www.w3schools.com/howto/tryit.asp?filename=tryhow_css_fixed_footer by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 30 Jul 2018 02:09:43 GMT -->
</html> 